const chatIcon = document.getElementById("chat-icon");
const chatBox = document.getElementById("chat-box");
const chatMessages = document.getElementById("chat-messages");
const userInput = document.getElementById("user-input");

// === OUVERTURE / FERMETURE DU CHAT ===
chatIcon.onclick = () => {
  chatBox.classList.toggle("hidden");
  if (!chatBox.classList.contains("hidden")) {
    userInput.focus();
  }
};

// === ENVOI MESSAGE PAR ENTRÉE ===
userInput.addEventListener("keydown", (e) => {
  if (e.key === "Enter" && !e.shiftKey) {
    e.preventDefault();
    sendMessage();
  }
});

// === ENVOI DU MESSAGE À FLASK/Ollama ===
async function sendMessage() {
  const message = userInput.value.trim();
  if (!message) return;

  const userMsg = addMessage("user", message);
  userInput.value = "";

  const botMsg = addMessage("bot", "");
  botMsg.classList.add("typing");

  try {
    const res = await fetch("http://localhost:5000/chat", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ message })
    });

    if (!res.ok) throw new Error("Réponse réseau invalide");

    const data = await res.json();
    const fullResponse = data.response || "Réponse vide.";

    botMsg.classList.remove("typing");
    typeEffect(botMsg, fullResponse); // ✨ effet typing

  } catch (err) {
    botMsg.classList.remove("typing");
    botMsg.textContent = "❌ Erreur serveur. Vérifie que Flask et Ollama tournent.";
    console.error("Erreur chatbot:", err);
  }
}

// === AJOUT D’UN MESSAGE DANS L’INTERFACE ===
function addMessage(sender, text) {
  const msg = document.createElement("div");
  msg.className = `message ${sender}`;
  msg.textContent = text;
  chatMessages.appendChild(msg);
  chatMessages.scrollTop = chatMessages.scrollHeight;
  return msg;
}

// === EFFET LETTRE PAR LETTRE COMME ChatGPT ===
function typeEffect(element, text, delay = 15) {
  let i = 0;
  const interval = setInterval(() => {
    if (i < text.length) {
      element.textContent += text[i++];
      chatMessages.scrollTop = chatMessages.scrollHeight;
    } else {
      clearInterval(interval);
    }
  }, delay);
}

// === RENDRE LE CHAT DRAGGABLE ===
dragElement(document.getElementById("chat-box"));

function dragElement(elmnt) {
  const header = document.getElementById("chat-header");
  let pos1 = 0, pos2 = 0, pos3 = 0, pos4 = 0;

  if (header) {
    header.onmousedown = dragMouseDown;
  }

  function dragMouseDown(e) {
    e.preventDefault();
    pos3 = e.clientX;
    pos4 = e.clientY;
    document.onmouseup = closeDragElement;
    document.onmousemove = elementDrag;
  }

  function elementDrag(e) {
    e.preventDefault();
    pos1 = pos3 - e.clientX;
    pos2 = pos4 - e.clientY;
    pos3 = e.clientX;
    pos4 = e.clientY;
    elmnt.style.top = (elmnt.offsetTop - pos2) + "px";
    elmnt.style.left = (elmnt.offsetLeft - pos1) + "px";
    elmnt.style.bottom = "auto";
    elmnt.style.right = "auto";
  }

  function closeDragElement() {
    document.onmouseup = null;
    document.onmousemove = null;
  }
}

// === DRAG ICON FLOTANT ===
const dragIcon = document.getElementById("chat-icon");
let isDragging = false;
let offsetX, offsetY;

dragIcon.addEventListener("mousedown", (e) => {
  isDragging = true;
  offsetX = e.clientX - dragIcon.getBoundingClientRect().left;
  offsetY = e.clientY - dragIcon.getBoundingClientRect().top;
  dragIcon.style.transition = "none";
});

document.addEventListener("mousemove", (e) => {
  if (isDragging) {
    dragIcon.style.left = e.clientX - offsetX + "px";
    dragIcon.style.top = e.clientY - offsetY + "px";
    dragIcon.style.right = "auto";
    dragIcon.style.bottom = "auto";
    dragIcon.style.position = "fixed";
  }
});

document.addEventListener("mouseup", () => {
  isDragging = false;
  dragIcon.style.transition = "all 0.2s ease";
});
