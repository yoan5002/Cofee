from flask import Flask, request, jsonify, send_from_directory
from flask_cors import CORS
import requests

app = Flask(__name__, static_folder="frontend")
CORS(app)

# === ROUTES STATIQUES ===
@app.route("/")
def index():
    return send_from_directory(app.static_folder, "index.html")

@app.route("/style.css")
def css():
    return send_from_directory(app.static_folder, "style.css")

@app.route("/script.js")
def js():
    return send_from_directory(app.static_folder, "script.js")

# === ROUTE CHAT SANS STREAMING ===
@app.route("/chat", methods=["POST"])
def chat():
    user_input = request.json.get("message", "").strip()

    if not user_input:
        return jsonify({"response": "Pose-moi une question liée à StarCoffe 😊"}), 400

    try:
        # ✅ Utilisation correcte pour Ollama avec réponse complète
        response = requests.post(
            "http://localhost:11434/api/generate",
            json={
                "model": "mistral",
                "prompt": f"""Tu es un assistant du site StarCoffe. Réponds uniquement sur nos produits, commandes, paiements, livraisons, retours. Sois chaleureux et humain.\n\nUtilisateur : {user_input}\nAssistant :""",
                "stream": False
            }
        )

        data = response.json()
        message = data.get("response", "").strip()
        return jsonify({"response": message or "Réponse vide."})

    except Exception as e:
        print("❌ Erreur serveur :", e)
        return jsonify({"response": "❌ Erreur serveur. Vérifie que Ollama fonctionne."}), 500

if __name__ == "__main__":
    app.run(debug=True)
